/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlineshoppingcartproject;

/**
 *
 * @author Bobby Lo
 */
public class ItemToPurchase {

    //declare instance variables 
    private String itemName;
    private int itemPrice;
    private int itemQuantity;
    private String itemDescription; 

    // Zero argumented constructors
    public ItemToPurchase() {
        this.itemName = "none";
        this.itemPrice = 0;
        this.itemQuantity = 0;
        this.itemDescription = "none";
    }

    //getters and setters for variables 
    public ItemToPurchase(String itemName, int itemPrice, int itemQuantity) {
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.itemQuantity = itemQuantity;
        this.itemDescription = itemDescription;
    }

    //getter and setters for name
    public void setName(String itemName) {
        this.itemName = itemName;
    }

    public String getName() {
        return itemName;
    }

    //getter and setters for price
    public void setPrice(int itemPrice) {
        this.itemPrice = itemPrice;
    }

    public int getPrice() {
        return itemPrice;
    }

    //getter and setters for quantity
    public void setQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public int getQuantity() {
        return itemQuantity;
    }
    public void setDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public String getDescription() {
        return itemDescription;
    }

    public void printItemCost() {
        System.out.println(itemName + " " + itemQuantity + " @ $" + itemPrice + " = $" + (itemPrice * itemQuantity));
    }

    public void printItemDescription() {
        System.out.println(itemName + ": " + itemDescription);
    }
}
