/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileio;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Bobby Lo
 */

class FileIO {

    public static void main(String[] args) {
        try {
            copyFile("english.txt", "copy.txt");
            translateFile("english.txt", "piglatin.txt");
        } catch (IOException e) {
            System.out.println("exception:" + e.getMessage());
        }
    }

    public static void copyFile(String fileName1, String fileName2) throws IOException {
        FileInputStream iStrm = new FileInputStream(fileName1);
        FileOutputStream oStrm = new FileOutputStream(fileName2);

        int b;
        while ((b = iStrm.read()) != -1) {
            oStrm.write(b);
        }
        iStrm.close();
        oStrm.close();
    }

    public static void translateFile(String fileName, String fileName2) throws IOException {

        Scanner readFile = new Scanner(new File(fileName));
        FileWriter writeFile = new FileWriter(fileName2);

        while (readFile.hasNextLine()) {
            String line = readFile.nextLine();
            String[] words = line.split("\\s+");

            for (int index = 0; index < words.length; index++) {
                words[index] = (words[index].substring(1) + words[index].charAt(0) + "ay");
                writeFile.write(words[index] + " ");
            }
            writeFile.write("\n");
        }
        writeFile.close();
        readFile.close();
    }
}
