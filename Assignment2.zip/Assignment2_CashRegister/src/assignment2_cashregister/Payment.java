/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2_cashregister;

/**
 *
 * @author Bobby Lo
 */
public class Payment {

    private PaymentType type; //private fields for Payment type
    private double amount; // private field for amount in double 

    public Payment(PaymentType type, double amount) { //instantiates a new payment
        this.type = type; //fields set to values
        this.amount = amount;
    }

    public PaymentType getType() { //getter for payment type
        return type;
    }

    public void setType(PaymentType type) { // setter for payment type
        this.type = type; //sets type to whatever type is set
    }

    public double getAmount() { // getter for amount
        return amount;
    }

    public void setAmount(double amount) { // setter for amount
        this.amount = amount; //sets amount field to whatever is set
    }

    @Override
    public String toString() { // toString generated for payment and amount
        return type + " = " + amount; // returns payment type equals the amount 
    }
}
