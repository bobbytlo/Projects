/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2_cashregister;

/**
 *
 * @author Bobby Lo
 */
public class Receipt {

    private final TransactionCalc transaction; //private final field for TranactionCalc will store transaction for each receipt 

    public Receipt(TransactionCalc transaction) { //private receipt field withTransactionCalc as paramenter
        this.transaction = transaction;
    }
    // getter for transaction calc
    public TransactionCalc getTransactionCalc() {
        return transaction;
    }

    //getter for receipt 
    public String getReceiptString() {
        String s = ""; //initialize string
        for (int i = 0; i < transaction.getItems().size(); i++) { //lists the items name and prices in receipt 
            s += transaction.getItems().get(i).toString() + "\n";
        }
        s += "----------------------------------------\n"; //divider 
        s += "Subtotal: \t" + transaction.getSubTotal() + "\nTax:\t" + transaction.getTax() + "\nTotal:\t" //lists subtotal, tax and total
                + transaction.getTotal() + "\n";
        
        for (int i = 0; i < transaction.getPayments().size(); i++) { // lists all payment type and amount user inputted 
             s += transaction.getPayments().get(i).toString() + "\n";
        }
        s += "Change: \t" + transaction.getChange(); //prints change to transaction getChange
        return s; // return string s
    }
}
