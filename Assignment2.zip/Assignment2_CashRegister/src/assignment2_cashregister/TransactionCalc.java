/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2_cashregister;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Bobby Lo
 */
public class TransactionCalc { //method to calculate transaction totals

    // private fields 
    private ArrayList<Items> items; // arrayList that holds items
    private ArrayList<Payment> payments;// arraylist that holds payments 
    private double subTotal; 
    private double tax; 
    private double total; 
    private double change; 

    public TransactionCalc() { //default constructor for TransactionCalc
        this.items = new ArrayList<>(); //instantiates  arraylist for items
        this.payments = new ArrayList<>(); // instantiates arraylist for payment 
    }

    public TransactionCalc(ArrayList<Items> items) { // constuctor that has paramenter arraylist item
        this.items = items;
        this.payments = new ArrayList<>(); //initializes this.payments
    }

    
    //getters and setters for each field
    public ArrayList<Items> getItems() {
        return items;
    }

    // sets arraylist items to item
    public void setItems(ArrayList<Items> items) {
        this.items = items;
    }
    //getter for payments and returns payments
    public ArrayList<Payment> getPayments() {
        return payments;
    }
    //set array list payments to payment 
    public void setPayments(ArrayList<Payment> payments) {
        this.payments = payments;
    }

    
    //getter for subTotal and returns subtotal
    public double getSubTotal() {
        return subTotal;
    }

    // setter for subtotal and sets subtotal double to value that was set
    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }

    //getter for total and returns total
    public double getTotal() {
        return total;
    }

    //setter for total and sets the total to double and what value set
    public void setTotal(double total) {
        this.total = total;
    }

    //getter for change and returns change
    public double getChange() {
        return change;
    }

    //setter for change, sets change to a double and sets to value 
    public void setChange(double change) {
        this.change = change;
    }
    
    //getter and setter for tax
    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    //computes subtotal 
    public double computeSubtotal() {
        double subtotal = 0; //initialized to 0 
        for (Items item : items) { // sets items to items in turn
            subtotal += item.getPrice();
        }
        setSubTotal(subtotal); //sets subtotal to subtotal
        return subTotal; //returns subtotal
    }

    public void computeTax() { //constructo for computing tax
        double tax = subTotal * .07; //subtotal mulitplied by .07
        setTax(tax); //sets tax as subtotal times .07
    }

    //compute the total price
    public void computeTotal() {
        double total = subTotal + tax; // total is subtotal plus tax 
        setTotal(total); //sets the total to total
    }
    
    private void menu() { // menu to list all payment types

        System.out.println("1. Cash\n" + "2. Debit Card\n" + "3. Credit Card\n" + "4. Check\n");
    }

    // constructor takePayment 
    public void takePayment() { 
        Scanner scan = new Scanner(System.in); // uses Scanner to scan user keyboard input
        double paidAmount = 0; //initializes paid Amount to 0 
        String paymentType = ""; //initializes payment type 
        computeSubtotal(); //refered to computeSubtotal constructor
        computeTax(); // referred to compute tax constructor
        computeTotal(); // referred to compute total constructor

        for (int i = 0; i < items.size(); i++) {

            System.out.println("Item " + (i + 1) + " : " + items.get(i).toString()); //prints item and increases each item bu
            //one 
        }
        System.out.println("Total : " + getTotal()); // prints total 
        System.out.print("Enter payment type: \n"); //prompts user to input payment type
        do { // runs each case 
            menu();
            int type = scan.nextInt(); //searches for user input type
            switch (type) { // switch case for type 
                case 1:
                    paymentType = "CASH";
                    break; // break statements to come out of switch body
                case 2:
                    paymentType = "DEBIT_CARD";
                    break;
                case 3:
                    paymentType = "CREDIT_CARD";
                    break;
                case 4:
                    paymentType = "CHECK";
                    break;

                default:
                    System.out.println("Invalid choice"); //if not choosing 1-4 cases
                    break;
            }
            System.out.print("How much you want to pay by " + paymentType + " : "); //prints how much user wants to pay by type 
            
            double amount = scan.nextDouble(); // smount is stored as double 
            
            paidAmount += amount; // the paidamount user inputted is saved to amount and assign amount to new a amount 
            
            payments.add(new Payment(PaymentType.valueOf(paymentType), amount)); // new payment if applicable 
        } while (paidAmount < getTotal()); // will repeat if paidamount is smalled than total

        change = paidAmount - total; //change is set to paidamount - total
    }

}


