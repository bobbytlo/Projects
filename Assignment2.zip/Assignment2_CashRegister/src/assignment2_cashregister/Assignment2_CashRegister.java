/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2_cashregister;

import java.util.ArrayList;

/**
 *
 * @author Bobby Lo
 */
public class Assignment2_CashRegister {

    /**
     * @param args the command line arguments
     *
     */
    public static void main(String[] args) {  //main method to  plug any items into with their prices 
        ArrayList<Items> items = new ArrayList<>(); //arraylist named items
        items.add(new Items("Honeydew", 20.0)); //any item and their price
        items.add(new Items("Strawberry", 20.5));
        items.add(new Items("Pineapple", 10.5));

        TransactionCalc transaction = new TransactionCalc(items); //create transaction object with user input
        transaction.takePayment(); // takes payment
        Receipt receipt = new Receipt(transaction); //reciept object created for item transaction
        System.out.println(receipt.getReceiptString()); // prints out receipt 
    }

}
