/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2_cashregister;

/**
 *
 * @author Bobby Lo
 */
public class Items {

    private String name; //private field for string name 
    private double price; // private field for price double

    public Items(String name, double price) { //instantiates new items
        this.name = name; //set fields to respective values
        this.price = price;
    }

    public String getName() { // getter for name
        return name;
    }

    public void setName(String name) { //setter for name 
        this.name = name; //set name field to what was set
    }

    public double getPrice() { //getter for price
        return price;
    }

    public void setPrice(double price) { //setter for price
        { //sets price field to what was set
            this.price = price;
        }
    }

    @Override //generated toString to return item name and price to be printed
    public String toString() {
        return name + ": " + price; // retuns and lists name and  price 
    }
}
